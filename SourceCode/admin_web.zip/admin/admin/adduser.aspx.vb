﻿
Partial Class adduser
    Inherits System.Web.UI.Page

End Class
