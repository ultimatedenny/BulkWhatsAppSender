﻿Imports Microsoft.VisualBasic

Public Class UserDetails
    Public UserID As Long
    Public UserName As String
    Public Password As String
    Public Fullname As String
    Public Email As String
    Public Mobile As String
    Public Country As String
    Public CreatedDate As String
    Public Status As Integer
End Class
